from django.contrib import admin

from .models import models





# ----------- inline stacks
class VideoInlineStack(admin.StackedInline):
    
    model = models.Ep
    extra = 0
    verbose_name = "حلقة"
    verbose_name_plural = "حلقات"



#------------Instructor


#------------ AdminModels

class CoursesAdminStyle(admin.ModelAdmin):
    list_display = ["more", "instructor", "name_ar", "name_en"]
    list_display_links = ["more"]
    inlines      = [
        VideoInlineStack,
    ]
    list_filter = []



    search_fields = ["name_ar", "name_en", "instructor__name_ar", "instructor__name_en"]



admin.site.register(models.Instructor, )
admin.site.register(models.Courses   ,CoursesAdminStyle )
