from typing import Any
from django.shortcuts import render, redirect
from django.http      import HttpRequest, HttpResponse
from .form            import UserCustomForm
from django.urls      import reverse
from django.contrib.auth.views  import  LoginView

# Landing Page Request Handle Function
def landing(req:HttpRequest, lang=None) -> HttpResponse:
    
    if  lang == None:
        return redirect(
            reverse("core:landing", args=["en"])
        )
    context = {

        "lang"     : lang,
        "active"   : "home"

    }

    return  render(req, "pages/landing.html", context=context)




def signup(req:HttpRequest, lang=None) -> HttpResponse:

    if  lang == None:
        return redirect(
            reverse("core:signup", args=["en"])
        )

    if req.method == "POST":
        form = UserCustomForm(req.POST)

        if form.is_valid():
            form.save()

            return redirect(reverse("core:login"))

    form = UserCustomForm()

    context = {
        "form" : form,
        "lang" : lang
    }
    
    return  render(req, "pages/signup.html", context)


class LoginViewSec(LoginView):
    
    
    def get_context_data(self, **kwargs: Any) -> dict[str, Any]:
        x = super().get_context_data(**kwargs)
        x['lang'] = self.kwargs.get("lang", None)
        if  x['lang'] == None:
            return redirect(reverse("core:login", args=["en"]))

        return x
    
    def render_to_response(self, context: dict[str, Any], **response_kwargs: Any) -> HttpResponse:
        
        x = self.kwargs.get("lang", None)
        if  x == None:
            return redirect(
                reverse("core:login", args=["en"])
            )
        
        return super().render_to_response(context, **response_kwargs)
    
def change_lang(req:HttpRequest):
    
    url:str = req.META['HTTP_REFERER']
    
    if "en" in url:


        url = url.replace("en", "ar")
    elif "ar" in url:

        url = url.replace("ar", "en")

    return redirect(url)





def course_list_view(req:HttpRequest, lang=None):
    if  lang == None:
        
        return redirect(
            reverse("core:couese_list_view", args=["en"])
        )
    
    context = {
        "lang" : lang,
        "active": "courses"
    }
    return render(req, "pages/courses.html", context)