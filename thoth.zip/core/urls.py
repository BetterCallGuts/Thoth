from django.urls import path
from . import views
from django.contrib.auth.views  import   LogoutView


app_name = "core"

urlpatterns = [
    
    path("change_lang/", views.change_lang,                                                 name="change_lang"     ),
    path("signup/",      views.signup,                                                      name="signup"          ),
    path("login/",       views.LoginViewSec.as_view(template_name="pages/login.html"),      name="login"           ),
    path("signup/<str:lang>/", views.signup,                                                name="signup"          ),
    path("login/<str:lang>/",  views.LoginViewSec.as_view(template_name="pages/login.html"),name="login"           ),
    path("", views.landing      ,                                                           name="landing"         ),
    path("logout/", LogoutView.as_view(),                                                   name="logout"          ),
    path("welcome/<str:lang>/", views.landing      ,                                        name="landing"         ),
    path("Courses/<str:lang>/", views.course_list_view,                                     name="couese_list_view"),
    
]
