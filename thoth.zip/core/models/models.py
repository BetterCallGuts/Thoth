from django.db import models
from datetime import datetime
from django.core.validators import FileExtensionValidator

class Instructor(models.Model):

    name_ar = models.CharField(max_length=255, verbose_name="اسم المدرس")
    name_en = models.CharField(max_length=255, verbose_name="name in english")
    photo_banner = models.ImageField(upload_to="instructors_photos", blank=True, null=True)
    
    def __str__(self):

        return f"{self.name_ar}"
    class Meta:
        verbose_name        = "المدرس"
        verbose_name_plural = "المدرسين"
        

class Courses(models.Model):

    banner    = models.ImageField(verbose_name="thumbnail", upload_to="courses_banner_general", blank=True, null=True)
    instructor = models.ForeignKey(Instructor, verbose_name="المدرس", on_delete=models.CASCADE)
    name_ar    = models.CharField(max_length=255, verbose_name="اسم كورس")
    name_en    = models.CharField(max_length=255, verbose_name="اسم الكورس انجليزي")
    description_en= models.TextField(null=True, blank=True)
    description_ar= models.TextField(null=True, blank=True, verbose_name="وصف بالعربي")

    def __str__(self):
        return f"{self.instructor}|{self.name_ar}"
    class Meta:
        
        verbose_name = "كورس"
        verbose_name_plural = "كورسات"
    def more(self):
        return "انقر للمزيد"
    
    more.short_description = "انقر للمزيد"


class Ep(models.Model):
    course    = models.ForeignKey(Courses, on_delete=models.CASCADE)
    banner    = models.ImageField(verbose_name="thumbnail", upload_to="courses_banner", blank=True, null=True)
    video     = models.FileField(upload_to="course", verbose_name="الفيديو",
    validators=[FileExtensionValidator(
        allowed_extensions=["mp4", "webm", "avi", "AVI", "WebM"])],
    help_text='Allowed : "mp4", "webm", "avi", "AVI", "WebM" ')
    name_ar   = models.CharField(max_length=255, verbose_name="اسم الحلقة عربي")
    name_en   = models.CharField(max_length=255, verbose_name="اسم الحلقة انجليزي")
    descr_en  = models.TextField(blank=True, null=True, verbose_name="description ")
    descr_ar  = models.TextField(blank=True, null=True, verbose_name="وصف ")
    created_in= models.DateField(default=datetime.now, editable=False)

